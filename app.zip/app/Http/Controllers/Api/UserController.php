<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return response()->json($users);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'photo' => 'mimes:png,jpeg,jpg',
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'role_as' => 'required|integer',
        ]);

        // Create a new Post instance with the validated data
        $user = new User([
            'name' => $validatedData['name'],
            'email' => $validatedData['email'],
            'password' => bcrypt(request($validatedData['password'])),
            'position' => $validatedData['position'],
            'role_as' => $validatedData['role_as'],
        ]);

        $user->save(); // Save the new post to the database

        return response()->json($user); // Return the new post as JSON
    }

    public function show($id)
    {
        $user = User::find($id);
        if(!empty($user))
        {
            return response()->json($user);
        }
        else
        {
            return response()->json([
                "message" => "User not found"
            ], 404);
        }

    }
}
