<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Bootstrap -->
    
    <link href="<?php echo e(asset('assets/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('assets/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(asset('assets/vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset('assets/css/custom.min.css')); ?>" rel="stylesheet">


</head>
<body class="nav-md">
    <div class="container body">
        <div class="main_container">

            <!-- Sidebar Nav -->
            <?php echo $__env->make('layouts.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!--Navbar-->
            

            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>


            <!-- footer content -->
            <footer>
                <div class="pull-right">MultiUser App - <a href="#">Qatar</a></div>
                <div class="clearfix"></div>
            </footer>
            <!-- /footer content -->

        </div>
    </div>


    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/vendors/jquery/dist/jquery.min.js')); ?>"></script>
    
    
    <!-- Bootstrap -->
    
    <script src="<?php echo e(asset('assets/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('assets/vendors/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo e(asset('assets/vendors/nprogress/nprogress.js')); ?>"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(asset('assets/js/custom.min.js')); ?>"></script>

    <!-- page specific scripts -->
    <?php echo $__env->yieldContent('specificPagesScript'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\user-app\resources\views/layouts/master.blade.php ENDPATH**/ ?>