

<?php $__env->startSection('title', 'Users - Multiuser App'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Users</h3>
        </div>
        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
              <a href="/admin/user/create" class="btn btn-primary btn-block btn-lg"> + Add New User </a>
            </div>
        </div>
    </div>

    <div class="clearfix"></div>
    <?php if(session('message')): ?>
        <div class="alert alert-success alert-dismissible fade in" role="alert"><?php echo e(session('message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                
                <div class="x_content">  
                    <div class="table-responsive">
                        <table class="table table-striped jambo_table data-table">
                            <thead>
                                <tr class="headings">
                                <th class="column-title">ID</th>
                                <th class="column-title">Name </th>
                                <th class="column-title">Email </th>
                                <th class="column-title">Photo </th>
                                <th class="column-title">Role </th>
                                <th class="column-title">Created By </th>
                                
                                <th class="column-title no-link last"><span class="nobr">Action</span>
                                </th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="even pointer">
                                    <td class=" "><?php echo e($index + 1); ?>.</td>
                                    <td class=" "><?php echo e($row->name); ?></td>
                                    <td class=" "><?php echo e($row->email); ?></td>
                                    <td>
                                        <div class="showPhoto">
                                            <div id="imagePreview" style="<?php if($row->photo != ''): ?> background-image:url('<?php echo e(url('/')); ?>/uploads/<?php echo e($row->photo); ?>')<?php else: ?> background-image: url('<?php echo e(url('/assets/images/img.jpg')); ?>') <?php endif; ?>;">
                                            </div>
                                        </div>
                                    </td>
                                    <?php if($row->role_as == '1'): ?>
                                        <td class=" "><span class="label label-success">Admin</span></td>
                                    <?php elseif($row->role_as == '2'): ?>
                                        <td class=" "><span class="label label-info">HR</span></td>
                                    <?php else: ?>
                                        <td class=" "><span class="label label-default">User</span></td>
                                    <?php endif; ?>
                                    <td class=" "><?php echo e($row->created_at); ?></td>
                                    
                                    <td>
                                        <a href="<?php echo e(url('admin/view-user/'.$row->id)); ?>" class="btn btn-info btn-xs"><i class="fa fa-eye"></i> View </a>
                                        <a href="<?php echo e(url('admin/edit/'.$row->id)); ?>" class="btn btn-warning btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                                        <form method="POST" action="<?php echo e(url('admin/delete', $row->id)); ?>" style="display: inline-table;">
                                            <?php echo csrf_field(); ?>
                                            <input name="_method" type="hidden" value="DELETE">
                                            <button type="submit" class="btn btn-xs btn-danger show_confirm" data-toggle="tooltip" title='Delete'><i class="fa fa-trash-o"></i> Delete</button>
                                        </form>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('specificPagesScript'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<script type="text/javascript">
 
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to delete this User?`,
              text: "If you delete this, it will be gone forever.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
                form.submit();
            }
          });
      });
  
</script>

<style>
    .showPhoto {
        width: 60%;
        height: 50px;
        margin: auto;
    }
 
    .showPhoto>div {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\user-app\resources\views/admin/users/index.blade.php ENDPATH**/ ?>