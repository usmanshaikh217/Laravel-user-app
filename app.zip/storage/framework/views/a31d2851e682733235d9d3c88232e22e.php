

<?php $__env->startSection('title', 'Users - Multiuser App'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Profile</h3>
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>User Report <small>Activity report</small></h2>

              <div class="clearfix"></div>
            </div>
            <div class="x_content">
              <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                <div class="profile_img">
                  <div id="crop-avatar">
                    <!-- Current avatar -->
                    <img class="img-responsive avatar-view" src="<?php echo e(asset('assets/images/picture.jpg')); ?>" alt="Avatar" title="Change the avatar">
                  </div>
                </div>
                <h3><?php echo e(Auth::user()->name); ?></h3>

                <ul class="list-unstyled user_data">

                  <li>
                    <i class="fa fa-briefcase user-envelop-icon"></i> <?php echo e(Auth::user()->email); ?>

                  </li>
                  
                  <li><i class="fa fa-map-marker user-profile-icon"></i> Lusail, Qatar
                  </li>

                  <li>
                    <i class="fa fa-briefcase user-profile-icon"></i> <?php echo e(Auth::user()->position); ?>

                  </li>

                  <li class="m-top-xs">
                    <i class="fa fa-external-link user-profile-icon"></i>
                    <a href="http://www.google.com/" target="_blank">www.google.com</a>
                  </li>
                </ul>

                <br>

              

              </div>
              <div class="col-md-9 col-sm-9 col-xs-12">

              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\user-app\resources\views/profile.blade.php ENDPATH**/ ?>