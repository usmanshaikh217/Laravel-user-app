<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('User Summary')); ?></div>

                <div class="card-body">

                    <div class="x_panel">
                        <div class="x_title">
                          
                          <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
      
                          <table class="table table-bordered">
                            <thead>
                              <tr>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Position</th>
                                <th>Role</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td>
                                    <div class="showPhoto">
                                        <div id="imagePreview" style="<?php if($item->photo != ''): ?> background-image:url('<?php echo e(url('/')); ?>/uploads/<?php echo e($item->photo); ?>')<?php else: ?> background-image: url('<?php echo e(url('/assets/images/img.jpg')); ?>') <?php endif; ?>;width:80px;height:80px">
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->position); ?></td>
                                <?php if($item->role_as == '1'): ?>
                                <td>Admin</td>
                                <?php elseif($item->role_as == '2'): ?>
                                <td>HR</td>
                                <?php else: ?>
                                <td>User</td>
                                <?php endif; ?>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
      
                        </div>
                      </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\user-app\resources\views/list.blade.php ENDPATH**/ ?>